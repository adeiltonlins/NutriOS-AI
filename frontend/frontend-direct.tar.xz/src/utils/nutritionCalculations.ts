import { Gender, SkinfoldMeasurements, CircumferenceMeasurements } from '../types';

export function calculateBMI(weightKg: number, heightCm: number): { value: number; classification: string; color: string } {
  if (!weightKg || !heightCm) return { value: 0, classification: 'N/A', color: 'text-gray-400' };
  const heightM = heightCm / 100;
  const bmi = Number((weightKg / (heightM * heightM)).toFixed(1));
  
  let classification = 'Eutrofia (Peso Normal)';
  let color = 'text-emerald-500';

  if (bmi < 18.5) {
    classification = 'Abaixo do peso';
    color = 'text-amber-500';
  } else if (bmi >= 25 && bmi < 29.9) {
    classification = 'Sobrepeso (Pré-obesidade)';
    color = 'text-amber-600';
  } else if (bmi >= 30 && bmi < 34.9) {
    classification = 'Obesidade Grau I';
    color = 'text-rose-500';
  } else if (bmi >= 35 && bmi < 39.9) {
    classification = 'Obesidade Grau II';
    color = 'text-rose-600';
  } else if (bmi >= 40) {
    classification = 'Obesidade Grau III (Mórbida)';
    color = 'text-red-700';
  }

  return { value: bmi, classification, color };
}

// Harris-Benedict revised (1984)
export function calculateHarrisBenedict(weight: number, height: number, age: number, gender: Gender): number {
  if (gender === 'masculino') {
    return Math.round(88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age));
  } else {
    return Math.round(447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age));
  }
}

// Mifflin-St Jeor (considered gold standard for overweight and general population)
export function calculateMifflinStJeor(weight: number, height: number, age: number, gender: Gender): number {
  const base = (10 * weight) + (6.25 * height) - (5 * age);
  return Math.round(gender === 'masculino' ? base + 5 : base - 161);
}

// Cunningham (requires Lean Mass in kg)
export function calculateCunningham(leanMassKg: number): number {
  return Math.round(370 + (21.6 * leanMassKg));
}

// Katch-McArdle (based on Fat-Free Mass)
export function calculateKatchMcArdle(weightKg: number, bodyFatPercent: number): number {
  const leanMass = weightKg * (1 - bodyFatPercent / 100);
  return Math.round(370 + (21.6 * leanMass));
}

// Tinsley (specifically developed for bodybuilders / resistance-trained individuals)
export function calculateTinsley(weightKg: number): number {
  return Math.round((24.8 * weightKg) + 10);
}

// Henry & Rees (Oxford equations)
export function calculateOxford(weight: number, heightCm: number, age: number, gender: Gender): number {
  if (gender === 'masculino') {
    if (age < 30) return Math.round(14.4 * weight + 313 * (heightCm / 100) + 113);
    if (age < 60) return Math.round(11.4 * weight + 541 * (heightCm / 100) - 137);
    return Math.round(11.4 * weight + 541 * (heightCm / 100) - 256);
  } else {
    if (age < 30) return Math.round(10.4 * weight + 615 * (heightCm / 100) - 282);
    if (age < 60) return Math.round(8.18 * weight + 502 * (heightCm / 100) - 11.6);
    return Math.round(8.52 * weight + 421 * (heightCm / 100) + 10.7);
  }
}

// METs Database for Physical Activity
export interface METActivity {
  id: string;
  name: string;
  category: string;
  met: number;
  description: string;
}

export const MET_ACTIVITIES_DATABASE: METActivity[] = [
  { id: 'met-1', name: 'Musculação Intensa / Hipertrofia', category: 'Resistido', met: 6.0, description: 'Séries pesadas com 60-90s de descanso' },
  { id: 'met-2', name: 'CrossFit / Treino Funcional Intenso', category: 'Híbrido', met: 8.5, description: 'WOD com alta frequência cardíaca' },
  { id: 'met-3', name: 'Corrida Moderada (9 a 10 km/h)', category: 'Cardio', met: 9.8, description: 'Pace entre 6:00 e 6:40 min/km' },
  { id: 'met-4', name: 'Corrida Intensa / Tiros (> 12 km/h)', category: 'Cardio', met: 12.5, description: 'Treino de velocidade / fartlek' },
  { id: 'met-5', name: 'Ciclismo em Estrada / Spinning Moderado', category: 'Cardio', met: 7.5, description: 'Cadência moderada a vigorosa' },
  { id: 'met-6', name: 'Natação Estilo Livre / Crawl Moderado', category: 'Cardio', met: 8.0, description: 'Nado contínuo em piscina' },
  { id: 'met-7', name: 'Beach Tennis / Tênis de Quadra', category: 'Esporte', met: 7.3, description: 'Jogo dinâmico com sprints curtos' },
  { id: 'met-8', name: 'Futebol / Futsal Recreativo', category: 'Esporte', met: 8.0, description: 'Corrida intervalada contínua' },
  { id: 'met-9', name: 'Pilates / Yoga / Alongamento', category: 'Mobilidade', met: 3.2, description: 'Fortalecimento postural e core' },
  { id: 'met-10', name: 'Caminhada Rápida (5.5 a 6.0 km/h)', category: 'Cardio', met: 3.8, description: 'Caminhada acelerada ao ar livre' }
];

export function calculateWorkoutCalories(met: number, weightKg: number, durationMinutes: number): number {
  return Math.round(met * weightKg * (durationMinutes / 60));
}


// Pollock 3 Skinfolds Protocol
export function calculatePollock3(skinfolds: SkinfoldMeasurements, age: number, gender: Gender): number {
  if (gender === 'masculino') {
    // Chest, Abdomen, Thigh
    const sum3 = (skinfolds.chest || 0) + (skinfolds.abdominal || 0) + (skinfolds.thigh || 0);
    if (sum3 === 0) return 0;
    const bodyDensity = 1.10938 - (0.0008267 * sum3) + (0.0000016 * sum3 * sum3) - (0.0002574 * age);
    // Siri equation
    const bf = ((4.95 / bodyDensity) - 4.5) * 100;
    return Number(Math.max(3, Math.min(60, bf)).toFixed(1));
  } else {
    // Triceps, Suprailiac, Thigh
    const sum3 = (skinfolds.triceps || 0) + (skinfolds.suprailiac || 0) + (skinfolds.thigh || 0);
    if (sum3 === 0) return 0;
    const bodyDensity = 1.0994921 - (0.0009929 * sum3) + (0.0000023 * sum3 * sum3) - (0.0001392 * age);
    const bf = ((4.95 / bodyDensity) - 4.5) * 100;
    return Number(Math.max(8, Math.min(65, bf)).toFixed(1));
  }
}

// Pollock 7 Skinfolds Protocol (Chest, Midaxillary, Triceps, Subscapular, Abdomen, Suprailiac, Thigh)
export function calculatePollock7(skinfolds: SkinfoldMeasurements, age: number, gender: Gender): number {
  const sum7 = (skinfolds.chest || 0) + 
               (skinfolds.axillary || 0) + 
               (skinfolds.triceps || 0) + 
               (skinfolds.subscapular || 0) + 
               (skinfolds.abdominal || 0) + 
               (skinfolds.suprailiac || 0) + 
               (skinfolds.thigh || 0);
  if (sum7 === 0) return 0;

  let bodyDensity = 0;
  if (gender === 'masculino') {
    bodyDensity = 1.112 - (0.00043499 * sum7) + (0.00000055 * sum7 * sum7) - (0.00028826 * age);
  } else {
    bodyDensity = 1.097 - (0.00046971 * sum7) + (0.00000056 * sum7 * sum7) - (0.00012828 * age);
  }

  const bf = ((4.95 / bodyDensity) - 4.5) * 100;
  return Number(Math.max(4, Math.min(65, bf)).toFixed(1));
}

// Calculate Total Daily Energy Expenditure (TDEE / GET)
export function calculateTDEE(bmr: number, activityFactor: number): number {
  return Math.round(bmr * activityFactor);
}

// Activity factor descriptions
export const ACTIVITY_FACTORS = [
  { value: 1.2, label: 'Sedentário (pouco ou nenhum exercício diário)' },
  { value: 1.375, label: 'Levemente Ativo (exercício 1-3 dias/semana)' },
  { value: 1.55, label: 'Moderadamente Ativo (exercício 3-5 dias/semana)' },
  { value: 1.725, label: 'Muito Ativo (exercício pesado 6-7 dias/semana)' },
  { value: 1.9, label: 'Extremamente Ativo (atleta profissional / treino 2x ao dia)' }
];

// Waist-to-Hip Ratio (RCQ)
export function calculateWHR(waistCm: number, hipCm: number, gender: Gender): { value: number; risk: string; color: string } {
  if (!waistCm || !hipCm) return { value: 0, risk: 'N/A', color: 'text-gray-400' };
  const whr = Number((waistCm / hipCm).toFixed(2));
  
  let risk = 'Baixo Risco Cardiovascular';
  let color = 'text-emerald-500';

  if (gender === 'masculino') {
    if (whr >= 0.90 && whr <= 0.95) {
      risk = 'Risco Moderado';
      color = 'text-amber-500';
    } else if (whr > 0.95) {
      risk = 'Alto Risco Cardiovascular';
      color = 'text-rose-500';
    }
  } else {
    if (whr >= 0.80 && whr <= 0.85) {
      risk = 'Risco Moderado';
      color = 'text-amber-500';
    } else if (whr > 0.85) {
      risk = 'Alto Risco Cardiovascular';
      color = 'text-rose-500';
    }
  }

  return { value: whr, risk, color };
}
