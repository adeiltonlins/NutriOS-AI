import React from 'react';
import { 
  LayoutDashboard, 
  Users, 
  UtensilsCrossed, 
  Calculator, 
  Scale, 
  Dumbbell, 
  Leaf, 
  HeartPulse, 
  ArrowLeftRight, 
  FileText, 
  Apple, 
  CalendarDays, 
  DollarSign,
  Smartphone, 
  Sparkles, 
  Bot, 
  ShieldCheck, 
  Globe, 
  Sliders, 
  Crown 
} from 'lucide-react';

export type NavView = 
  | 'dashboard'
  | 'patients'
  | 'meal_planner'
  | 'workout_planner'
  | 'metabolic_calc'
  | 'anthropometry'
  | 'phytotherapy'
  | 'msq_tracking'
  | 'equivalents_guide'
  | 'lab_exams'
  | 'food_database'
  | 'appointments'
  | 'financial'
  | 'super_admin'
  | 'patient_portal'
  | 'landing_page';

interface SidebarProps {
  activeView: NavView;
  onNavigate: (view: NavView) => void;
  onOpenCopilot: () => void;
  patientsCount: number;
  userRole?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  onNavigate,
  onOpenCopilot,
  patientsCount,
  userRole
}) => {
  const clinicalItems = [
    { id: 'dashboard' as NavView, label: 'Visão Geral', icon: LayoutDashboard, badge: null },
    { id: 'patients' as NavView, label: 'Pacientes & Prontuários', icon: Users, badge: patientsCount },
    { id: 'meal_planner' as NavView, label: 'Prescrição & Cardápios', icon: UtensilsCrossed, badge: 'IA Pro' },
    { id: 'workout_planner' as NavView, label: 'Prescrição de Treinos', icon: Dumbbell, badge: 'Vídeos & Fichas' },
    { id: 'metabolic_calc' as NavView, label: 'Calculadora Metabólica', icon: Calculator, badge: '7 Fórmulas' },
    { id: 'anthropometry' as NavView, label: 'Antropometria & 3D', icon: Scale, badge: '4 Fotos' },
    { id: 'phytotherapy' as NavView, label: 'Fitoterapia & Receituário', icon: Leaf, badge: 'Timbrado' },
    { id: 'msq_tracking' as NavView, label: 'Rastreamento MSQ / IFM', icon: HeartPulse, badge: 'IA' },
    { id: 'equivalents_guide' as NavView, label: 'Equivalentes & Trocas', icon: ArrowLeftRight, badge: 'TACO' },
    { id: 'lab_exams' as NavView, label: 'Exames Laboratoriais', icon: FileText, badge: 'IA' },
    { id: 'food_database' as NavView, label: 'Tabela de Alimentos', icon: Apple, badge: 'TACO' },
    { id: 'appointments' as NavView, label: 'Agenda & Consultas', icon: CalendarDays, badge: 'Hoje' },
    { id: 'financial' as NavView, label: 'Financeiro & Faturamento', icon: DollarSign, badge: 'R$ Recibos' },
  ];


  return (
    <aside className="w-64 shrink-0 bg-white border-r border-emerald-100 flex flex-col justify-between p-3.5 transition-colors hidden md:flex min-h-[calc(100vh-61px)]">
      
      {/* Navigation List */}
      <div className="space-y-4 overflow-y-auto pr-1">
        
        {/* Clinical Section */}
        <div>
          <p className="px-3 text-[10px] font-extrabold text-slate-400 uppercase tracking-wider mb-1.5">
            Atendimento Clínico & Prescrições
          </p>

          <div className="space-y-0.5">
            {clinicalItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;

              return (
                <button
                  key={item.id}
                  id={`sidebar-nav-${item.id}`}
                  onClick={() => onNavigate(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl font-semibold text-xs transition-all text-left ${
                    isActive
                      ? 'bg-emerald-50 text-emerald-800 font-bold shadow-sm border border-emerald-200/80'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-600' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>

                  {item.badge !== null && (
                    <span className={`text-[9px] px-1.5 py-0.5 rounded-md font-extrabold ${
                      item.badge === 'IA Pro' || item.badge === 'IA'
                        ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white'
                        : item.badge === 'Timbrado' || item.badge === '7 Fórmulas' || item.badge === 'Vídeos & Fichas'
                        ? 'bg-emerald-100 text-emerald-800'
                        : isActive
                        ? 'bg-emerald-200 text-emerald-900'
                        : 'bg-slate-100 text-slate-600'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

      </div>

      {/* Footer Copilot CTA */}
      <div className="pt-3 border-t border-emerald-100 space-y-2">
        <button
          onClick={onOpenCopilot}
          className="w-full py-2.5 px-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all hover:scale-[1.02]"
        >
          <Bot className="w-4 h-4" />
          <span>Copiloto NutriOS IA</span>
        </button>
      </div>

    </aside>
  );
};
