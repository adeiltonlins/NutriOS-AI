import React, { useEffect, useState } from 'react';
import { 
  Apple, 
  Search, 
  Plus, 
  Filter, 
  Flame, 
  Layers, 
  X,
  Sparkles
} from 'lucide-react';
import { FoodDatabaseItem } from '../types';
import { api } from '../api';

export const FoodDatabaseView: React.FC = () => {
  const [foods, setFoods] = useState<FoodDatabaseItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);


  useEffect(() => {
    const q = searchTerm.trim();
    if (q.length < 2) { setFoods([]); return; }
    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const rows = await api.foods(q);
        setFoods(rows.map((x:any) => ({
          id:String(x.id), name:x.nome||x.name||'Alimento', category:'Carboidratos',
          portionDescription:'100 g', standardGrams:100, calories:Number(x.kcal||0), protein:Number(x.proteina_g||0),
          carbs:Number(x.carboidrato_g||0), fats:Number(x.lipideos_g||0), fiber:Number(x.fibra_g||0),
          sodiumMg:Number(x.sodio_mg||0), ironMg:Number(x.ferro_mg||0), calciumMg:Number(x.calcio_mg||0), photoUrl:''
        })));
      } finally { setLoading(false); }
    }, 250);
    return () => clearTimeout(timer);
  }, [searchTerm]);
  // New Food State
  const [name, setName] = useState('');
  const [category, setCategory] = useState<FoodDatabaseItem['category']>('Proteínas');
  const [portionDescription, setPortionDescription] = useState('1 porção média (100g)');
  const [standardGrams, setStandardGrams] = useState<number>(100);
  const [calories, setCalories] = useState<number>(150);
  const [protein, setProtein] = useState<number>(20);
  const [carbs, setCarbs] = useState<number>(0);
  const [fats, setFats] = useState<number>(5);
  const [fiber, setFiber] = useState<number>(0);

  const categories = [
    'all',
    'Proteínas',
    'Carboidratos',
    'Gorduras Boas',
    'Frutas',
    'Vegetais & Saladas',
    'Laticínios',
    'Suplementos'
  ];

  const filteredFoods = foods.filter(f => {
    const matchesSearch = f.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = selectedCategory === 'all' || f.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const handleAddFood = (e: React.FormEvent) => {
    e.preventDefault();
    alert('O cadastro de alimento personalizado será salvo pelo backend do NutriOS quando o endpoint dedicado estiver habilitado. A busca TACO já usa a base real.');
    setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-16">
      
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
              Tabela de Alimentos & Composição (TACO / USDA)
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
              Tabela Brasileira
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Base oficial de alimentos com densidade calórica, distribuição de macronutrientes e micronutrientes.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Cadastrar Alimento Personalizado</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-800/90 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Buscar por nome do alimento (ex: Frango, Aveia, Salmão, Banana)..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:border-emerald-500"
          />
        </div>

        {/* Category Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-1">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              {cat === 'all' ? 'Todos os Alimentos' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Foods Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredFoods.map(food => (
          <div
            key={food.id}
            className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 p-4 shadow-sm hover:border-emerald-500/50 transition-all flex flex-col justify-between gap-3"
          >
            <div className="flex items-start gap-3">
              <img
                src={food.photoUrl || 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22120%22 height=%22120%22 viewBox=%220 0 120 120%22%3E%3Crect width=%22120%22 height=%22120%22 rx=%2220%22 fill=%22%23ecfdf5%22/%3E%3Cpath d=%22M60 28c-18 0-29 13-29 31 0 21 16 33 29 33s29-12 29-33c0-18-11-31-29-31Z%22 fill=%22%2310b981%22/%3E%3C/svg%3E'}
                alt={food.name}
                className="w-14 h-14 rounded-xl object-cover ring-2 ring-emerald-500/20 shrink-0"
              />
              <div>
                <span className="text-[10px] font-bold text-emerald-600 uppercase">
                  {food.category}
                </span>
                <h3 className="font-bold text-xs text-slate-900 dark:text-white leading-snug mt-0.5">
                  {food.name}
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  {food.portionDescription} ({food.standardGrams}g)
                </p>
              </div>
            </div>

            {/* Macros Bar */}
            <div className="grid grid-cols-4 gap-1.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-900/60 text-center text-xs">
              <div>
                <span className="text-[9px] text-slate-400 font-bold block">KCAL</span>
                <strong className="text-slate-900 dark:text-white">{food.calories}</strong>
              </div>
              <div>
                <span className="text-[9px] text-emerald-600 font-bold block">PROT</span>
                <strong className="text-emerald-600">{food.protein}g</strong>
              </div>
              <div>
                <span className="text-[9px] text-teal-600 font-bold block">CARB</span>
                <strong className="text-teal-600">{food.carbs}g</strong>
              </div>
              <div>
                <span className="text-[9px] text-amber-600 font-bold block">GORD</span>
                <strong className="text-amber-600">{food.fats}g</strong>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* MODAL: ADD FOOD */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg p-6 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 mb-4">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Cadastrar Alimento na Tabela</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddFood} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Nome do Alimento</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Iogurte Skyr Natural"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Categoria</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                  >
                    {categories.filter(c => c !== 'all').map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Porção e Gramagem</label>
                  <input
                    type="text"
                    value={portionDescription}
                    onChange={(e) => setPortionDescription(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Calorias (kcal)</label>
                  <input
                    type="number"
                    value={calories}
                    onChange={(e) => setCalories(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-emerald-600 uppercase mb-1">Proteínas (g)</label>
                  <input
                    type="number"
                    value={protein}
                    onChange={(e) => setProtein(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border text-xs font-bold text-emerald-600"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-teal-600 uppercase mb-1">Carbos (g)</label>
                  <input
                    type="number"
                    value={carbs}
                    onChange={(e) => setCarbs(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border text-xs font-bold text-teal-600"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-amber-600 uppercase mb-1">Gorduras (g)</label>
                  <input
                    type="number"
                    value={fats}
                    onChange={(e) => setFats(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border text-xs font-bold text-amber-600"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-500 hover:bg-slate-100 rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs hover:bg-emerald-500"
                >
                  Salvar na Tabela
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
